# Changelog

## 3 July 2016

- Use html5mode instead of hash navigation.

## 24 June 2016

- Be able to import Component's templates and styles without using require.
