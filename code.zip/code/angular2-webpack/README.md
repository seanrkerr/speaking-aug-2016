preboot obtained from here

https://github.com/preboot/angular2-webpack.git 