import { Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'my-about',
  encapsulation: ViewEncapsulation.Emulated,
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {

  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello About');
  }

}
