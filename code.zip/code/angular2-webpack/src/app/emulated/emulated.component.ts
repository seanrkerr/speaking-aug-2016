import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AboutComponent } from '../about/about.component';

@Component({
  selector: 'my-emulated',
  encapsulation: ViewEncapsulation.Emulated,
  directives: [AboutComponent],
  templateUrl: './emulated.component.html',
  styleUrls: ['./emulated.component.scss']
})
export class EmulatedComponent implements OnInit {
  public title = 'This is emulated encapsulation';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello emulated');
  }

}
