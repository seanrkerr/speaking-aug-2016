import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AboutComponent } from '../about/about.component'; //here i'm importing the about component to demonstrate nested components in agnualr 2'

@Component({
  selector: 'my-emulated',
  encapsulation: ViewEncapsulation.Emulated,
  directives: [AboutComponent], //i add the component in, at this stage I'm not concerned about it name, this is only a demo'
  templateUrl: './emulated.component.html',
  styleUrls: ['./emulated.component.scss']
})
export class EmulatedComponent implements OnInit {
  public title = 'This is emulated encapsulation';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello emulated');
  }

}
