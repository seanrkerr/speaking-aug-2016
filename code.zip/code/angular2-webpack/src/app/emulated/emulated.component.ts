import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'my-emulated',
  encapsulation: ViewEncapsulation.Emulated,
  templateUrl: './emulated.component.html',
  styleUrls: ['./emulated.component.scss']
})
export class EmulatedComponent implements OnInit {
  public title = 'This is emulated emulation';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello emulated');
  }

}
