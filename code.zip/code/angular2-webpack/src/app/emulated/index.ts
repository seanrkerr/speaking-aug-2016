export * from './emulated.component';
