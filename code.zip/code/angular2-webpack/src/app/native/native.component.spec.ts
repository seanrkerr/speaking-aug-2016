import {
  async,
  inject,
  addProviders
} from '@angular/core/testing';

import { TestComponentBuilder } from '@angular/compiler/testing';

import { NativeComponent } from './native.component';

describe('Native Component', () => {
  beforeEach(() => {
    addProviders([]);
  });

  it('should ...', async(inject([TestComponentBuilder], (tcb: TestComponentBuilder) => {
    tcb.createAsync(NativeComponent).then((fixture) => {
      fixture.detectChanges();
    });
  })));

});
