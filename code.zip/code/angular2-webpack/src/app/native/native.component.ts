import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'my-native',
  encapsulation: ViewEncapsulation.Native,
  templateUrl: './native.component.html',
  styleUrls: ['./native.component.scss']
})
export class NativeComponent implements OnInit {
  public title = 'This is Native emulation';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello native');
  }

}
