import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'my-none',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './none.component.html',
  styleUrls: ['./none.component.scss']
})
export class NoneComponent implements OnInit {
  public title = 'This component has no emulation set';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
    console.log('Hello none');
  }

}
