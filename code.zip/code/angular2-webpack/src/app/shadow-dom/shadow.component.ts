import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-about',
  templateUrl: './shadow.component.html',
  styleUrls: ['./shadow.component.scss']
})
export class ShadowDomComponent implements OnInit {
   public title = 'Shadow DOM demonstration';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
  }

}
