import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'my-shadow',
  templateUrl: './shadow.component.html',
  encapsulation: ViewEncapsulation.Native,
  styleUrls: ['./shadow.component.scss']
})
export class ShadowDomComponent implements OnInit {
   public title = 'Shadow DOM demonstration';
  constructor() {
    // Do stuff
  }

  ngOnInit() {
  }

}
